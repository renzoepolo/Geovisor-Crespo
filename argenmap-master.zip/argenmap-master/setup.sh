#!/bin/bash
cp examples/menu.json js/